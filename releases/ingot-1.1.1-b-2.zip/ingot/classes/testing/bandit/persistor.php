<?php
/**
 * Acts as intermediary between Bandit and CRUD
 *
 * @package   ingot
 * @author    Josh Pollock <Josh@JoshPress.net>
 * @license   GPL-2.0+
 * @link
 * @copyright 2015 Josh Pollock
 */

namespace ingot\testing\bandit;


use MaBandit\Persistence\AbstractPersistor;

class persistor extends AbstractPersistor {}

