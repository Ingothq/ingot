## 0.1.0
Initial release

## 0.2.0
Major refactor and overhaul of UI

## 0.2.0.1
* Simpler verification of click tracking.
* Better handling of failed click tracking.
