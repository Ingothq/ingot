<?php
/**
 * Price test multi-armed bandit implementation
 *
 * @package   ingot
 * @author    Josh Pollock <Josh@JoshPress.net>
 * @license   GPL-2.0+
 * @link
 * @copyright 2015 Josh Pollock
 */

namespace ingot\testing\bandit;


class price extends content {
	//@todo find a reason why this class is needed at all or rm it
}
