# 0.2.2
* Improved compatibility with WordPress 4.4
* Plugin header meta data
* Show version number in admin header

# 0.2.1
* Price testing for Easy Digital Downloads -- still experimental
* Major UI improvements

## 0.2.0.1
* Simpler verification of click tracking.
* Better handling of failed click tracking.

## 0.2.0
Major refactor and overhaul of UI

## 0.1.0
Initial release
