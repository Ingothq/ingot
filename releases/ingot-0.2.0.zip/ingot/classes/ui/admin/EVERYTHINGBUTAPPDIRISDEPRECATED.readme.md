Everything in this directory besides the directory app is depreacted. That's all old stuff that sucks. Still exists to make it easier for Josh to canalize anything he needs.
